# kavach > 2023-03-28 8:30pm
https://universe.roboflow.com/selection-task/kavach-rmfel

Provided by a Roboflow user
License: CC BY 4.0

